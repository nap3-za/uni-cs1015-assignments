import math


def day_of_week(day, month, year):
    # Your code here


def is_leap(year):
    # Your code here


def month_num(month_name):
    # Your code here

def num_days_in(month_num, year):
    # Your code here


def num_weeks(month_num, year):
    # Your code here


def week(week_num, start_day, days_in_month):
    # Your code here


def main():
    # Your code here


if __name__=='__main__':
    main()






