# Given a word, calculate how many syllables it contains.

def count_syllables(word):
    count = 0
    # Your code here.

def main():
    word = input('Enter a word (or \'q\' to quit):\n')
    # Your code here.

# Do not modify.
if __name__ == '__main__':
    main()

